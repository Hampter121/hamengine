/**
 * 
 */
/**
 * 
 */
module phys_engine {
	requires java.desktop;
	requires jdk.compiler;


}